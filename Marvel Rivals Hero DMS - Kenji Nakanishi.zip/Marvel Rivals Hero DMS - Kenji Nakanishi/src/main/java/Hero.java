public class Hero{
        private final String identityHeroID;
        private final String heroName;
        private final int healthPoint;
        private final int movementSpeed;
        private final int ultDamage;
        private final String heroRole;
        private final double winRate;

   // Constructor
    public Hero (String identityHeroID, String heroName, int healthPoint, int movementSpeed,
                 int ultDamage, String heroRole, double winRate) {
        this.identityHeroID = identityHeroID;
        this.heroName = heroName;
        this.healthPoint = healthPoint;
        this.movementSpeed = movementSpeed;
        this.ultDamage = ultDamage;
        this.heroRole = heroRole;
        this.winRate = winRate;
    }

    // Getters
    public String  getIdentityHeroID() {
        return identityHeroID;
    }
    public String getHeroName() {
        return heroName;
    }
    public int getHealthPoint() {return healthPoint;}
    public int getMovementSpeed() {
        return movementSpeed;
    }
    public int getUltDamage() {return ultDamage;}
    public String getHeroRole(){
        return heroRole;
    }
    public double getWinRate(){
        return winRate;
    }

    //This will set the format to print on CLI
    @Override
    public String toString() {
        return String.format("%s-%s-%s-%s-%s-%s-%.2f%%", identityHeroID, heroName, healthPoint, movementSpeed, ultDamage, heroRole, winRate);
    }
    // This will set the format to storage on cvs and txt file
    public String toFileLine(){
        return identityHeroID + "-" + heroName + "-" + healthPoint + "-" + movementSpeed + "-" + ultDamage + "-" + heroRole + "-" + String.format("%.2f", winRate);
    }
}
